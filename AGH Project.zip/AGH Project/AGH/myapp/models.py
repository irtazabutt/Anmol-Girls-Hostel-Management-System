from django.db import models
from django.conf import settings

# Use default user model
User = settings.AUTH_USER_MODEL

class Service(models.Model):
    service_icon=models.CharField(max_length=50)
    service_title=models.CharField(max_length=50)
    service_des=models.TextField()

# contact us form
class Contact(models.Model):
    INQUIRY_CHOICES = [
        ('booking', 'Room Booking'),
        ('mess', 'Mess / Food'),
        ('fees', 'Hostel Fees'),
        ('visit', 'Visit Request'),
        ('complaint', 'Complaint'),
        ('other', 'Other'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    inquiry_type = models.CharField(max_length=20, choices=INQUIRY_CHOICES, default='other')
    message = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.inquiry_type}"    


class RoomBooking(models.Model):

    ROOM_CHOICES = [
        ('single', 'Single Room - 35000'),
        ('shared', 'Shared Room - 25000'),
        ('triple', 'Triple Room - 22000'),
    ]

    DURATION_CHOICES = [
        ('1_month', '1 Month'),
        ('3_months', '3 Months'),
        ('6_months', '6 Months'),
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    room_type = models.CharField(max_length=10, choices=ROOM_CHOICES)
    duration = models.CharField(max_length=10, choices=DURATION_CHOICES)
    room_rent = models.IntegerField()
    booking_status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='pending'
    )
    
    total_amount = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.full_name


class Payment(models.Model):
    PAYMENT_METHODS = [
        ('jazzcash', 'JazzCash'),
        ('easypaisa', 'EasyPaisa'),
        ('bank', 'Bank Transfer'),
    ]

    booking = models.ForeignKey(RoomBooking, on_delete=models.CASCADE)
    method = models.CharField(max_length=20, choices=PAYMENT_METHODS)

    mobile_number = models.CharField(max_length=20)
    account_name = models.CharField(max_length=100)

    amount = models.IntegerField()
    transaction_id = models.CharField(max_length=100, blank=True)

    payment_status = models.CharField(
        max_length=20,
        default="Initiated"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.booking.full_name} - {self.method}"