from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
   path('about/', views.about, name='about'),
   path('contact/', views.contact, name='contact'),
   path('room-booking/', views.room_booking, name='room_booking'),
   path('payment/<int:booking_id>/', views.payment, name='payment'),
   path('booking-success/', views.booking_success, name='booking_success'),
   path('gallery/', views.gallery, name='gallery'),
   path('mess/', views.mess, name='mess'),
   path('signup/', views.signup, name='signup'),
   path('login/', views.login_user, name='login'),
   path('logout/', views.logout_user, name='logout'),

]




