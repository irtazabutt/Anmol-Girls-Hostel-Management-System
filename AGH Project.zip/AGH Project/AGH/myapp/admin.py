from django.contrib import admin
from myapp.models import Service
from myapp.models import Contact
from myapp.models import RoomBooking 
from myapp.models import Payment

# ---------- Service Admin (jo aapne diya hai) ----------
class serviceAdmin(admin.ModelAdmin):
    list_display=('service_icon', 'service_title', 'service_des')

admin.site.register(Service,serviceAdmin)

class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'inquiry_type', 'message', 'created_at')
    list_filter = ('inquiry_type', 'created_at')
    search_fields = ('name', 'email', 'phone', 'message')

admin.site.register(Contact, ContactAdmin)

@admin.register(RoomBooking)
class RoomBookingAdmin(admin.ModelAdmin):
    list_display = (
        'full_name',
        'room_type',
        'room_rent',
        'booking_status',
        'created_at'
    )
    list_filter = ('booking_status', 'room_type')
    search_fields = ('full_name', 'phone', 'email')
    list_editable = ('booking_status',)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = (
        'booking',
        'method',
        'amount',
        'payment_status',
        'created_at'
    )
    list_filter = ('method', 'payment_status')
    search_fields = ('booking__full_name', 'mobile_number')
