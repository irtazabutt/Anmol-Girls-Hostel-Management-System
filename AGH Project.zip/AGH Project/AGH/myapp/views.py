from django.shortcuts import render, redirect,  get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from myapp.models import Service # Service model import kiya gaya hai
from django.contrib import messages
from myapp.models import Contact
from django.contrib.auth.decorators import login_required
from myapp.models import RoomBooking, Payment
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout



# Create your views here.

# Function definition aur indentation zaroori hai
def index(request): 
    # Indentation shuru: Yeh sab function ke andar hona chahiye
    servicesData = Service.objects.all()
    print("SERVICES FETCHED:", servicesData)
    
    data = {
        'servicesData': servicesData
    } 
    
    # Template path ab 'main/index.html' use kar rahe hain (pichle issue ke mutabiq)
    return render(request, 'myapp/index.html', data)

def about(request):
    return render(request, 'myapp/about.html')

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        inquiry_type = request.POST.get('inquiry_type')
        message = request.POST.get('message')

        Contact.objects.create(
            name=name,
            email=email,
            phone=phone,
            inquiry_type=inquiry_type,
            message=message
        )

        messages.success(request, "Your message has been sent! We will contact you soon.")
        return redirect('contact')

    return render(request, 'myapp/contact.html')

@login_required(login_url='login')
def room_booking(request):
    if request.method == "POST":
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        room_type = request.POST.get('room_type')
        duration = request.POST.get('duration')

        prices = {
            'single': 35000,
            'shared': 25000,
            'triple': 22000
        }

        room_rent = prices.get(room_type, 0)
        total_amount = room_rent  # advance = room rent for demo

        booking = RoomBooking.objects.create(
            full_name=full_name,
            email=email,
            phone=phone,
            room_type=room_type,
            duration=duration,
            room_rent=room_rent,
            total_amount=total_amount
        )

        return redirect('payment', booking_id=booking.id)

    return render(request, 'myapp/room_booking.html')


def payment(request, booking_id):
    booking = get_object_or_404(RoomBooking, id=booking_id)

    # FIXED VALUES (ADMIN DECIDES)
    SECURITY_CHARGES = 5000
    ADVANCE_PAYMENT = 5000   # FIXED ADVANCE

    # USER WILL PAY ONLY THIS
    grand_total = SECURITY_CHARGES + ADVANCE_PAYMENT

    if request.method == "POST":
        method = request.POST.get('payment_method')
        account_name = request.POST.get('account_name')
        mobile_number = request.POST.get('mobile_number')
        transaction_id = request.POST.get('transaction_id')
        otp = request.POST.get('otp')

        # FAKE OTP CHECK
        if otp != "1234":
            messages.error(request, "Invalid OTP. Please enter correct OTP.")
            return redirect('payment', booking_id=booking.id)

        Payment.objects.create(
            booking=booking,
            method=method,
            account_name=account_name,
            mobile_number=mobile_number,
            amount=grand_total,
            transaction_id=transaction_id,
            payment_status='Paid'
        )

        messages.success(request, "Payment successful! Booking sent for approval.")
        return redirect('booking_success')

    context = {
        'booking': booking,
        'room_rent': booking.total_amount,
        'advance_payment': ADVANCE_PAYMENT,
        'security_charges': SECURITY_CHARGES,
        'grand_total': grand_total
    }

    return render(request, 'myapp/payment.html', context)

def booking_success(request):
    return render(request, 'myapp/booking_success.html')

def gallery(request):
    return render(request, 'myapp/gallery.html')

def mess(request):
    return render(request, 'myapp/mess.html')

def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        confirm_password = request.POST.get('password2')

        if password != confirm_password:
            messages.error(request, "Passwords do not match")
            return redirect('signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return redirect('signup')

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        login(request, user)
        messages.success(request, "Signup successful! You are now logged in.")
        return redirect('room_booking')

    return render(request, 'myapp/signup.html')



def login_user(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            messages.success(request, "Login successful")
            return redirect('room_booking')
        else:
            messages.error(request, "Invalid credentials")
            return redirect('login')

    return render(request, 'myapp/login.html')

def logout_user(request):
    logout(request)
    messages.success(request, "Logged out successfully")
    return redirect('login')



